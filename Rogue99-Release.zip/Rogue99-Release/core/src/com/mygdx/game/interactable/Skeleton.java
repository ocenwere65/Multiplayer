package com.mygdx.game.interactable;

public class Skeleton extends Enemy{
    //states
    boolean grouped;

    //public Skeleton(Tile tile, Rogue99 game){super(10, 0.5, 1, 2, 20, 3, "skeleton", tile, game);}
}
