package com.mygdx.game.item;

public class sword extends Weapon{
    public sword(int rarity, String sprite, int dmgModifier) {
        super(rarity, "sword", dmgModifier);
    }
}
