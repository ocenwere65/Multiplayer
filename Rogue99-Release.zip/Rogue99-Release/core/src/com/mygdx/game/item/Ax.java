package com.mygdx.game.item;

public class Ax extends Weapon{
    public Ax(int rarity, String sprite, int dmgModifier) {
        super(rarity, "axe", dmgModifier);
    }
}
